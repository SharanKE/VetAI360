import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import DashboardLayout from "./layouts/DashboardLayout";

import Login from "./pages/Login";
import Register from "./pages/Register";
import Landing from "./pages/Landing";
import Dashboard from "./pages/Dashboard";
import Livestock from "./pages/Livestock";
import AnimalProfile from "./pages/AnimalProfile";
import Monitoring from "./pages/Monitoring";
import PastureMap from "./pages/PastureMap";
import NearbyVets from "./pages/NearbyVets";
import VoiceAssistant from "./pages/VoiceAssistant";
import SymptomChecker from "./pages/SymptomChecker";
import ImageDiagnosis from "./pages/ImageDiagnosis";
import Vaccinations from "./pages/Vaccinations";
import AlertsPage from "./pages/AlertsPage";
import Telemedicine from "./pages/Telemedicine";
import AppointmentRoom from "./pages/AppointmentRoom";
import Admin from "./pages/Admin";
import NotFound from "./pages/NotFound";

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <FullScreenLoader />;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function FullScreenLoader() {
  return (
    <div className="flex h-screen w-full items-center justify-center bg-white">
      <div className="flex flex-col items-center gap-3">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-pasture-200 border-t-pasture-600" />
        <p className="font-mono text-xs tracking-wide text-pasture-700">LOADING VETAI 360…</p>
      </div>
    </div>
  );
}

export default function App() {
  const { user, loading } = useAuth();

  if (loading) return <FullScreenLoader />;

  return (
    <Routes>
      <Route path="/landing" element={<Landing />} />
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to="/" replace /> : <Register />} />

      {/* Root route: Unauthenticated visitors see Landing page; authenticated users see Dashboard */}
      <Route
        path="/"
        element={
          user ? (
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          ) : (
            <Landing />
          )
        }
      >
        <Route index element={user ? <Dashboard /> : null} />
      </Route>

      {/* Protected application feature routes */}
      <Route
        element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/livestock" element={<Livestock />} />
        <Route path="/livestock/:id" element={<AnimalProfile />} />
        <Route path="/monitoring" element={<Monitoring />} />
        <Route path="/pasture-map" element={<PastureMap />} />
        <Route path="/nearby-vets" element={<NearbyVets />} />
        <Route path="/voice-assistant" element={<VoiceAssistant />} />
        <Route path="/symptom-checker" element={<SymptomChecker />} />
        <Route path="/image-diagnosis" element={<ImageDiagnosis />} />
        <Route path="/vaccinations" element={<Vaccinations />} />
        <Route path="/alerts" element={<AlertsPage />} />
        <Route path="/telemedicine" element={<Telemedicine />} />
        <Route path="/telemedicine/:id" element={<AppointmentRoom />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
